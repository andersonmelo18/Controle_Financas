// js/cartoes.js
// VERSÃO 5.0 (Gestão de Limites, Bloqueio e Reversão de Pagamento)

import { 
    db, 
    ref, 
    set, 
    get, 
    push, 
    remove, 
    onValue, 
    child,
    update,
    off 
} from './firebase-config.js';
import { 
    getUserId, 
    formatCurrency, 
    parseCurrency,
    verificarSaldoSuficiente 
} from './main.js';

// ---- Variáveis Globais ----
let userId = null;
let currentYear = new Date().getFullYear();
let currentMonth = (new Date().getMonth() + 1).toString().padStart(2, '0');

/** Armazena a configuração dos cartões (nome, fechamento, etc.) */
let meusCartoes = {}; 
/** Armazena os listeners para podermos limpá-los */
let activeListeners = [];
/** Armazena os dados das faturas calculadas (para o KPI de total) */
let estadoFaturas = {};

// ---- Mapas de Ícones (dos outros módulos, para a tabela de fatura) ----
const categoriaIcones = {
    "Casa": "🏠", "Alimentação": "🛒", "Restaurante": "🍽️", "Transporte": "🚗",
    "Lazer": "🍿", "Saúde": "🩺", "Educação": "🎓", "Compras": "🛍️",
    "Serviços": "⚙️", "Outros": "📦"
};
const categoriaFixosIcones = {
    "Moradia": "🏠", "Contas": "💡", "Internet": "📺", "Transporte": "🚗",
    "Saude": "❤️", "Educacao": "🎓", "Seguros": "🛡️", "Outros": "📦"
};

// ---- Elementos DOM (Gerenciador) ----
const formAddCartao = document.getElementById('form-add-cartao');
const cartaoNomeInput = document.getElementById('cartao-nome');
const cartaoIconeSelect = document.getElementById('cartao-icone');
const cartaoFechamentoInput = document.getElementById('cartao-fechamento');
const cartaoVencimentoInput = document.getElementById('cartao-vencimento');
const cartaoLimiteInput = document.getElementById('cartao-limite'); // NOVO
const tbodyMeusCartoes = document.getElementById('tbody-meus-cartoes');

// ---- Elementos DOM (Faturas) ----
const faturasTabNav = document.getElementById('faturas-tab-nav');
const faturasTabContent = document.getElementById('faturas-tab-content');
const totalGastosCartoesEl = document.getElementById('total-gastos-cartoes-mes'); // NOVO

// ---- Elementos DOM (Modais) ----
const modalConfirm = document.getElementById('modal-confirm');
const modalMessage = document.getElementById('modal-message');
const modalEdit = document.getElementById('modal-edit-cartao');
const formEdit = document.getElementById('form-edit-cartao');
const editCartaoNomeInput = document.getElementById('edit-cartao-nome');
const editCartaoIconeSelect = document.getElementById('edit-cartao-icone');
const editCartaoFechamentoInput = document.getElementById('edit-cartao-fechamento');
const editCartaoVencimentoInput = document.getElementById('edit-cartao-vencimento');
const editCartaoLimiteInput = document.getElementById('edit-cartao-limite'); // NOVO
const btnCancelEdit = document.getElementById('modal-edit-btn-cancel');

// NOVO MODAL (Reverter Pagamento)
const modalReverter = document.getElementById('modal-reverter-confirm');
const modalReverterMessage = document.getElementById('modal-reverter-message');
const btnReverterConfirm = document.getElementById('modal-reverter-btn-confirm');
const btnReverterCancel = document.getElementById('modal-reverter-btn-cancel');

// ---- INICIALIZAÇÃO ----
document.addEventListener('authReady', (e) => {
    userId = e.detail.userId;
    document.addEventListener('monthChanged', (e) => {
        currentYear = e.detail.year;
        currentMonth = e.detail.month;
        loadGerenciadorCartoes(); 
    });
    
    const initialMonthEl = document.getElementById('current-month-display');
    if (initialMonthEl) {
        currentYear = initialMonthEl.dataset.year;
        currentMonth = initialMonthEl.dataset.month;
    }

    // Listeners dos formulários
    formAddCartao.addEventListener('submit', handleSalvarCartao);
    formEdit.addEventListener('submit', handleSalvarEditCartao);
    btnCancelEdit.addEventListener('click', () => modalEdit.style.display = 'none');

    loadGerenciadorCartoes();
});

function limparListeners() {
    activeListeners.forEach(l => off(l.ref, l.eventType, l.callback));
    activeListeners = [];
}

function listenToPath(path, callback, eventType = 'value') {
    const dataRef = ref(db, path);
    onValue(dataRef, callback);
    activeListeners.push({ ref: dataRef, eventType: eventType, callback: callback });
}

// ===============================================================
// FASE 2A: GERENCIADOR DE CARTÕES (Atualizado v5.0)
// ===============================================================

/**
 * Carrega a *configuração* dos cartões do usuário.
 * Este é o "gatilho" principal da página.
 * (v5.0: Fluxo alterado para carregar dados ANTES de renderizar tabelas)
 */
function loadGerenciadorCartoes() {
    limparListeners(); 
    
    const configPath = `dados/${userId}/cartoes/config`;
    const configRef = ref(db, configPath);

    // 1. Ouve a configuração
    onValue(configRef, (snapshot) => {
        meusCartoes = snapshot.val() || {};
        
        // 2. Carrega todos os dados de gastos
        // (A função checkAndRender DENTRO de loadGastosAgregados
        //  agora é responsável por renderizar TUDO)
        loadGastosAgregados();
    });
}

/**
 * (UI) Atualiza a tabela "Cartões Salvos"
 * (v5.0: Adiciona Limite Total e Status de Bloqueio)
 */
function atualizarTabelaCartoesSalvos() {
    tbodyMeusCartoes.innerHTML = '';
    const cartoes = Object.values(meusCartoes);

    if (cartoes.length === 0) {
        tbodyMeusCartoes.innerHTML = '<tr><td colspan="5">Nenhum cartão cadastrado.</td></tr>';
        return;
    }

    cartoes.forEach(cartao => {
        const tr = document.createElement('tr');
        tr.dataset.id = cartao.id;
        
        const isBloqueado = cartao.bloqueado || false;
        const statusClass = isBloqueado ? 'danger' : 'success';
        const statusIcon = isBloqueado ? 'lock' : 'lock_open';
        const statusText = isBloqueado ? 'Bloqueado' : 'Ativo';
        const toggleText = isBloqueado ? 'Desbloquear' : 'Bloquear';
        const toggleIcon = isBloqueado ? 'lock_open' : 'lock';

        tr.innerHTML = `
            <td>${cartao.icone} ${cartao.nome}</td>
            <td>${formatCurrency(cartao.limiteTotal || 0)}</td>
            <td><span class="tag ${statusClass}">${statusIcon} ${statusText}</span></td>
            <td>Dia ${cartao.diaVencimento}</td>
            <td class="actions">
                <button class="btn-icon ${isBloqueado ? 'success' : 'danger'} btn-block-cartao" title="${toggleText}">
                    <span class="material-icons-sharp">${toggleIcon}</span>
                </button>
                <button class="btn-icon warning btn-edit-cartao" title="Editar">
                    <span class="material-icons-sharp">edit</span>
                </button>
                <button class="btn-icon danger btn-delete-cartao" title="Excluir">
                    <span class="material-icons-sharp">delete</span>
                </button>
            </td>
        `;
        tr.querySelector('.btn-edit-cartao').addEventListener('click', handleEditCartaoClick);
        tr.querySelector('.btn-delete-cartao').addEventListener('click', handleDeleteCartaoClick);
        tr.querySelector('.btn-block-cartao').addEventListener('click', handleBlockToggleClick); // NOVO
        
        tbodyMeusCartoes.appendChild(tr);
    });
}

/**
 * (Form) Salva um novo cartão no Firebase
 * (v5.0: Adiciona limite e status 'bloqueado')
 */
async function handleSalvarCartao(e) {
    e.preventDefault();
    const nome = cartaoNomeInput.value;
    
    const nomeExistente = Object.values(meusCartoes).some(c => c.nome.toLowerCase() === nome.toLowerCase());
    if (nomeExistente) {
        alert(`❌ Erro: Já existe um cartão com o nome "${nome}".`);
        return;
    }

    const newRef = push(ref(db, `dados/${userId}/cartoes/config`));
    const cartaoData = {
        id: newRef.key,
        nome: nome,
        icone: cartaoIconeSelect.value,
        diaFechamento: parseInt(cartaoFechamentoInput.value),
        diaVencimento: parseInt(cartaoVencimentoInput.value),
        limiteTotal: parseCurrency(cartaoLimiteInput.value) || 0, // NOVO
        bloqueado: false // NOVO
    };

    try {
        await set(newRef, cartaoData);
        formAddCartao.reset();
    } catch (error) {
        console.error("Erro ao salvar cartão:", error);
        alert("Não foi possível salvar o cartão.");
    }
}

/**
 * (Modal) Abre o modal de edição com os dados do cartão
 * (v5.0: Adiciona limite)
 */
function handleEditCartaoClick(e) {
    const tr = e.target.closest('tr');
    if (!tr) return; // Proteção
    
    const id = tr.dataset.id;
    const cartao = meusCartoes[id];
    if (!cartao) return;

    formEdit.dataset.id = id;
    editCartaoNomeInput.value = cartao.nome;
    editCartaoIconeSelect.value = cartao.icone;
    editCartaoFechamentoInput.value = cartao.diaFechamento;
    editCartaoVencimentoInput.value = cartao.diaVencimento;
    editCartaoLimiteInput.value = formatCurrency(cartao.limiteTotal || 0); // NOVO

    modalEdit.style.display = 'flex';
}

/**
 * (Modal) Salva as alterações do cartão editado
 * (v5.0: Adiciona limite)
 */
async function handleSalvarEditCartao(e) {
    e.preventDefault();
    const id = formEdit.dataset.id;
    const path = `dados/${userId}/cartoes/config/${id}`;

    const nomeEditado = editCartaoNomeInput.value;
    const idDoNome = Object.keys(meusCartoes).find(key => meusCartoes[key].nome.toLowerCase() === nomeEditado.toLowerCase());
    
    if (idDoNome && idDoNome !== id) {
        alert(`❌ Erro: Já existe outro cartão com o nome "${nomeEditado}".`);
        return;
    }

    // Pega os dados antigos para não sobrescrever o 'bloqueado'
    const cartaoAntigo = meusCartoes[id] || {};

    const cartaoData = {
        ...cartaoAntigo, // Mantém dados existentes como 'bloqueado'
        id: id,
        nome: nomeEditado,
        icone: editCartaoIconeSelect.value,
        diaFechamento: parseInt(editCartaoFechamentoInput.value),
        diaVencimento: parseInt(editCartaoVencimentoInput.value),
        limiteTotal: parseCurrency(editCartaoLimiteInput.value) || 0 // NOVO
    };

    try {
        await update(ref(db, path), cartaoData); // Usa Update para preservar o 'bloqueado'
        modalEdit.style.display = 'none';
    } catch (error) {
        console.error("Erro ao atualizar cartão:", error);
        alert("Não foi possível atualizar o cartão.");
    }
}

// (Função v4.0, sem mudanças)
function handleDeleteCartaoClick(e) {
    const tr = e.target.closest('tr');
    if (!tr) return;
    
    const id = tr.dataset.id;
    const cartao = meusCartoes[id];
    if (!cartao) return;

    modalMessage.textContent = `Tem certeza que quer excluir o cartão "${cartao.nome}"? Isso não afeta os lançamentos já feitos.`;
    
    const deleteFn = async () => {
        try {
            await remove(ref(db, `dados/${userId}/cartoes/config/${id}`));
            hideModal('modal-confirm');
        } catch (error) {
            console.error("Erro ao excluir cartão:", error);
            alert("Não foi possível excluir o cartão.");
        }
    };
    
    showModal('modal-confirm', deleteFn);
}

/**
 * NOVO (v5.0): Alterna o status de bloqueio do cartão
 */
async function handleBlockToggleClick(e) {
    const tr = e.target.closest('tr');
    if (!tr) return;

    const id = tr.dataset.id;
    const cartao = meusCartoes[id];
    if (!cartao) return;

    const novoStatus = !(cartao.bloqueado || false); // Inverte o status
    const path = `dados/${userId}/cartoes/config/${id}/bloqueado`;

    try {
        await set(ref(db, path), novoStatus);
        // O listener 'onValue' em loadGerenciadorCartoes vai recarregar a UI
    } catch (error) {
        console.error("Erro ao alterar status do cartão:", error);
        alert("Não foi possível alterar o status do cartão.");
    }
}

// ===============================================================
// FASE 3A: LÓGICA DE FATURAS DINÂMICAS (Atualizado v5.0)
// ===============================================================

/** Estado global para armazenar os dados de gastos */
let estadoGastos = {
    despesas: {},
    fixos: {},
    specs: {},
    pendencias: {}
};

/**
 * Carrega todos os dados de gastos (v3.7)
 * (v5.0: checkAndRender agora renderiza TUDO)
 */
function loadGastosAgregados() {
    limparListeners(); 
    estadoGastos = { despesas: {}, fixos: {}, specs: {}, pendencias: {} };
    estadoFaturas = {}; // Limpa o estado das faturas
    
    const loadState = {
        despesasAtual: false,
        despesasAnt: false,
        fixosAtual: false,
        fixosAnt: false,
        specs: false,
        pendencias: false 
    };

    // v5.0: Esta função agora renderiza TUDO
    const checkAndRender = () => {
        if (Object.values(loadState).some(status => status === false)) {
            return; 
        }
        // Ordem de renderização importa!
        renderizarFaturas(); // 1. Calcula os totais e preenche 'estadoFaturas'
        atualizarTabelaCartoesSalvos(); // 2. Renderiza a tabela de gestão (agora precisa dos totais)
        atualizarAbasFatura(); // 3. Renderiza as abas (agora precisa do "melhor dia")
        ativarPrimeiraAba(); // 4. Ativa a primeira aba
        renderTotalGastosCartoes(); // 5. Renderiza o KPI de total
    };

    const dataAtual = new Date(currentYear, currentMonth - 1, 1);
    const dataAnterior = new Date(dataAtual);
    dataAnterior.setMonth(dataAnterior.getMonth() - 1);
    
    const mesAtualPath = `${currentYear}-${currentMonth}`;
    const mesAnteriorPath = `${dataAnterior.getFullYear()}-${(dataAnterior.getMonth() + 1).toString().padStart(2, '0')}`;

    // 1. Listeners para Despesas (mês atual e anterior)
    listenToPath(`dados/${userId}/despesas/${mesAtualPath}`, (snap) => {
        estadoGastos.despesas[mesAtualPath] = snap.val() || {};
        loadState.despesasAtual = true; 
        checkAndRender(); 
    }, 'value');
    listenToPath(`dados/${userId}/despesas/${mesAnteriorPath}`, (snap) => {
        estadoGastos.despesas[mesAnteriorPath] = snap.val() || {};
        loadState.despesasAnt = true; 
        checkAndRender(); 
    }, 'value');

    // 2. Listeners para Fixos (mês atual e anterior)
    listenToPath(`dados/${userId}/fixos/${mesAtualPath}`, (snap) => {
        estadoGastos.fixos[mesAtualPath] = snap.val() || {};
        loadState.fixosAtual = true; 
        checkAndRender(); 
    }, 'value');
    listenToPath(`dados/${userId}/fixos/${mesAnteriorPath}`, (snap) => {
        estadoGastos.fixos[mesAnteriorPath] = snap.val() || {};
        loadState.fixosAnt = true; 
        checkAndRender(); 
    }, 'value');

    // 3. Listener para Compras Parceladas (lê todos)
    listenToPath(`dados/${userId}/cartoes_specs`, (snap) => {
        estadoGastos.specs = snap.val() || {};
        loadState.specs = true; 
        checkAndRender(); 
    }, 'value');

    // 4. Listener para TODAS AS PENDÊNCIAS
    listenToPath(`dados/${userId}/pendencias`, (snap) => {
        estadoGastos.pendencias = snap.val() || {}; 
        loadState.pendencias = true; 
        checkAndRender(); 
    }, 'value');
}


/**
 * (UI) Cria as abas e os containers de conteúdo para cada cartão.
 * (v5.0: Adiciona "Melhor Dia Compra" e botão "Reverter")
 */
function atualizarAbasFatura() {
    faturasTabNav.innerHTML = '';
    faturasTabContent.innerHTML = '';
    
    const cartoes = Object.values(meusCartoes);

    if (cartoes.length === 0) {
        faturasTabNav.innerHTML = '<p style="padding: 1rem; color: var(--text-light);">Cadastre um cartão acima para ver as faturas.</p>';
        return;
    }

    cartoes.forEach(cartao => {
        // 1. Cria o Botão da Aba
        const tabBtn = document.createElement('button');
        tabBtn.className = 'tab-btn';
        tabBtn.dataset.cartaoId = cartao.id;
        
        // v5.0: Lógica do "Melhor Dia"
        let melhorDia = (cartao.diaFechamento || 0) + 1;
        // Se o fechamento é dia 31, melhor dia é 1
        if (melhorDia > 31) melhorDia = 1; 
        
        // v5.0: Lógica do Limite Disponível (Simplificada por enquanto)
        // O cálculo real é complexo. Por agora, mostramos o Limite Total.
        const limiteTotal = cartao.limiteTotal || 0;
        const faturaAtual = estadoFaturas[cartao.id]?.total || 0;
        // const limiteDisponivel = limiteTotal - ??? (precisamos do total em aberto, não só da fatura)
        
        tabBtn.innerHTML = `
            <div>${cartao.icone} ${cartao.nome}</div>
            <small style="color: ${faturaAtual > 0 ? 'var(--danger-color)' : 'var(--success-color)'};">
                ${formatCurrency(faturaAtual)}
            </small>
        `;
        
        tabBtn.addEventListener('click', handleTabClick);
        faturasTabNav.appendChild(tabBtn);

        // 2. Cria o Conteúdo da Aba
        const tabContent = document.createElement('div');
        tabContent.className = 'tab-content';
        tabContent.dataset.cartaoId = cartao.id;
        tabContent.style.display = 'none'; // Começa escondido
        
        tabContent.innerHTML = `
            <div class="fatura-header">
                <div>
                    <h2 id="total-fatura-${cartao.id}">R$ 0,00</h2>
                    <small>Fechamento: Dia ${cartao.diaFechamento} / Vencimento: Dia ${cartao.diaVencimento}</small>
                    <small style="color: var(--success-color); font-weight: 500; display: block; margin-top: 4px;">
                        Melhor dia de compra: Dia ${melhorDia}
                    </small>
                </div>
                <div class="fatura-actions">
                    <button class="btn-primary" id="btn-pagar-${cartao.id}" style="display: none;">Pagar Fatura</button>
                    <button class="btn-secondary danger" id="btn-reverter-pagamento-${cartao.id}" style="display: none;">
                        <span class="material-icons-sharp">undo</span> Reverter Pagamento
                    </button>
                </div>
            </div>
            <div class="table-container">
                <table id="table-fatura-${cartao.id}">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Descrição</th>
                            <th>Valor</th>
                        </tr>
                    </thead>
                    <tbody id="tbody-fatura-${cartao.id}">
                        <tr><td colspan="3">Nenhum gasto este mês.</td></tr>
                    </tbody>
                </table>
            </div>
        `;
        
        // Listener para o botão "Pagar"
        tabContent.querySelector(`#btn-pagar-${cartao.id}`).addEventListener('click', (e) => {
            const total = parseFloat(e.target.dataset.totalValor || 0);
            handlePagarFaturaClick(cartao, total);
        });
        
        // NOVO Listener para o botão "Reverter"
        tabContent.querySelector(`#btn-reverter-pagamento-${cartao.id}`).addEventListener('click', (e) => {
            const total = parseFloat(e.target.dataset.totalValor || 0);
            handleReverterPagamentoClick(cartao, total);
        });

        faturasTabContent.appendChild(tabContent);
    });
}

// (Função v3.7, sem mudanças)
function handleTabClick(e) {
    const targetId = e.target.closest('.tab-btn').dataset.cartaoId; // Mais robusto

    // Desativa todos os botões e conteúdos
    faturasTabNav.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    faturasTabContent.querySelectorAll('.tab-content').forEach(content => content.style.display = 'none');

    // Ativa o botão e conteúdo clicados
    faturasTabNav.querySelector(`.tab-btn[data-cartao-id="${targetId}"]`).classList.add('active');
    faturasTabContent.querySelector(`.tab-content[data-cartao-id="${targetId}"]`).style.display = 'block';
}

// (Função v3.7, sem mudanças)
function ativarPrimeiraAba() {
    const firstTabBtn = faturasTabNav.querySelector('.tab-btn');
    if (firstTabBtn) {
        firstTabBtn.click();
    }
}

/**
 * Função MESTRA que processa todos os gastos e preenche as faturas.
 * (v4.0 - Lógica de Quitar/Estornar)
 */
function renderizarFaturas() {
    if (Object.keys(meusCartoes).length === 0) return; 

    const dataFatura = new Date(currentYear, currentMonth - 1, 1);
    const dataFaturaAnterior = new Date(dataFatura);
    dataFaturaAnterior.setMonth(dataFaturaAnterior.getMonth() - 1);
    
    const mesAtualPath = `${currentYear}-${currentMonth}`;
    const mesAnteriorPath = `${dataFaturaAnterior.getFullYear()}-${(dataFaturaAnterior.getMonth() + 1).toString().padStart(2, '0')}`;

    // 1. Obter o status de pagamento de CADA fatura (atual e anterior)
    const statusPagamentoAtual = {};
    const statusPagamentoAnterior = {}; 

    Object.values(meusCartoes).forEach(cartao => {
        const nomeFatura = `Pagamento Fatura ${cartao.nome}`;
        
        statusPagamentoAtual[cartao.id] = Object.values(estadoGastos.pendencias[mesAtualPath] || {}).some(p => 
            p.descricao === nomeFatura && p.status === 'pago'
        );
        
        statusPagamentoAnterior[cartao.id] = Object.values(estadoGastos.pendencias[mesAnteriorPath] || {}).some(p => 
            p.descricao === nomeFatura && p.status === 'pago'
        );
    });

    // 2. Preparar objeto para armazenar totais e HTML
    estadoFaturas = {}; // Limpa o estado global de faturas
    Object.values(meusCartoes).forEach(cartao => {
        estadoFaturas[cartao.id] = { // USA O ESTADO GLOBAL
            nome: cartao.nome,
            total: 0, 
            html: '',
            pago: statusPagamentoAtual[cartao.id] 
        };
    });

    // 3. Processar Despesas e Fixos (lógica de "virada" E "trava")
    const fontesGastos = [
        ...Object.values(estadoGastos.despesas[mesAnteriorPath] || {}),
        ...Object.values(estadoGastos.despesas[mesAtualPath] || {}),
        ...Object.values(estadoGastos.fixos[mesAnteriorPath] || {}),
        ...Object.values(estadoGastos.fixos[mesAtualPath] || {})
    ];
    
    fontesGastos.forEach(gasto => {
        if (!gasto.data && !gasto.vencimento) return;
        
        const cartaoConfig = Object.values(meusCartoes).find(c => c.nome === gasto.formaPagamento);
        if (!cartaoConfig) return; 

        const dataGasto = new Date((gasto.data || gasto.vencimento) + 'T12:00:00');
        let mesFaturaAlvo = calcularMesFatura(dataGasto, cartaoConfig.diaFechamento);

        const isFaturaAnterior = (mesFaturaAlvo.getFullYear() === dataFaturaAnterior.getFullYear() &&
                                    mesFaturaAlvo.getMonth() === dataFaturaAnterior.getMonth());
        
        if (isFaturaAnterior && statusPagamentoAnterior[cartaoConfig.id]) {
            mesFaturaAlvo.setMonth(mesFaturaAlvo.getMonth() + 1);
        }

        const isFaturaAtual = (mesFaturaAlvo.getFullYear() === dataFatura.getFullYear() && 
                                mesFaturaAlvo.getMonth() === dataFatura.getMonth());

        if (isFaturaAtual && statusPagamentoAtual[cartaoConfig.id]) {
            mesFaturaAlvo.setMonth(mesFaturaAlvo.getMonth() + 1);
        }

        if (mesFaturaAlvo.getFullYear() === dataFatura.getFullYear() && 
            mesFaturaAlvo.getMonth() === dataFatura.getMonth()) {
            
            estadoFaturas[cartaoConfig.id].total += gasto.valor;
            estadoFaturas[cartaoConfig.id].html += renderLinhaGasto(gasto);
        }
    });

    // 4. Processar Compras Parceladas (cartoes_specs) (v4.0)
    Object.values(estadoGastos.specs).forEach(compra => {
        const cartaoConfig = Object.values(meusCartoes).find(c => c.nome === compra.cartao);
        if (!cartaoConfig) return;

        const [anoCompra, mesCompra] = compra.dataInicio.split('-');
        let dataInicioVirtual = new Date(anoCompra, mesCompra - 1, 1);
        
        // Lógica recursiva v3.7
        while (true) {
            const path = `${dataInicioVirtual.getFullYear()}-${(dataInicioVirtual.getMonth() + 1).toString().padStart(2, '0')}`;
            const pendenciasDesseMes = estadoGastos.pendencias[path] || {};
            const faturaPaga = Object.values(pendenciasDesseMes).some(p => 
                p.descricao === `Pagamento Fatura ${cartaoConfig.nome}` && p.status === 'pago'
            );
            if (faturaPaga) {
                dataInicioVirtual.setMonth(dataInicioVirtual.getMonth() + 1);
            } else {
                break;
            }
        }
        
        const [startYear, startMonth] = [dataInicioVirtual.getFullYear(), dataInicioVirtual.getMonth() + 1];
        const currentYearFatura = dataFatura.getFullYear();
        const currentMonthFatura = dataFatura.getMonth() + 1; 

        let mesesDiff = (currentYearFatura - startYear) * 12 + (currentMonthFatura - startMonth);
        let parcelaAtual = mesesDiff + 1; 
        
        if (parcelaAtual >= 1 && parcelaAtual <= compra.parcelas) {
            
            if (statusPagamentoAtual[cartaoConfig.id]) { 
                return; 
            }

            // Lógica v4.0 (Quitar/Estornar)
            const status = compra.status || 'ativo'; 
            const valorParcelaOriginal = compra.valorTotal / compra.parcelas;
            
            let valorParaTotal = 0;
            let isStrikethrough = false;
            let parcelaLabel = `(${parcelaAtual}/${compra.parcelas})`;

            if (status === 'estornado') {
                isStrikethrough = true;
                valorParaTotal = 0; 
                parcelaLabel = `(Estornado)`;
            } else if (status === 'quitado') {
                isStrikethrough = true;
                valorParaTotal = 0; 
                parcelaLabel = `(Quitado)`;
            } else if (status === 'quitado_pagamento') {
                isStrikethrough = false;
                valorParaTotal = valorParcelaOriginal; 
                parcelaLabel = `(Pagamento Quitação)`;
            } else {
                isStrikethrough = false;
                valorParaTotal = valorParcelaOriginal;
            }
            // --- FIM DA LÓGICA V4.0 ---
            
            estadoFaturas[cartaoConfig.id].total += valorParaTotal;
            estadoFaturas[cartaoConfig.id].html += renderLinhaGasto({
                data: `${currentYear}-${currentMonth}-01`, 
                descricao: `${compra.descricao} ${parcelaLabel}`,
                valor: valorParcelaOriginal, 
                categoria: 'Parcela',
                tipo: 'spec',
                isStrikethrough: isStrikethrough 
            });
        }
    });

    // 5. Atualizar a UI (totais, botões e tabelas)
    // (v5.0: Atualiza botões Pagar/Reverter)
    Object.values(meusCartoes).forEach(cartao => {
        const fatura = estadoFaturas[cartao.id];
        const totalEl = document.getElementById(`total-fatura-${cartao.id}`);
        const tbodyEl = document.getElementById(`tbody-fatura-${cartao.id}`);
        const btnPagarEl = document.getElementById(`btn-pagar-${cartao.id}`);
        const btnReverterEl = document.getElementById(`btn-reverter-pagamento-${cartao.id}`); // NOVO

        if (!totalEl || !tbodyEl || !btnPagarEl || !btnReverterEl) return;

        totalEl.textContent = formatCurrency(fatura.total);
        tbodyEl.innerHTML = fatura.html || '<tr><td colspan="3">Nenhum gasto este mês.</td></tr>';
        
        // Salva o total no dataset de ambos os botões
        btnPagarEl.dataset.totalValor = fatura.total;
        btnReverterEl.dataset.totalValor = fatura.total;

        if (fatura.pago) {
            btnPagarEl.style.display = 'none'; // Esconde Pagar
            btnReverterEl.style.display = 'flex'; // Mostra Reverter
            totalEl.style.color = 'var(--success-color)';
        } else if (fatura.total > 0) {
            btnPagarEl.style.display = 'flex'; // Mostra Pagar
            btnReverterEl.style.display = 'none'; // Esconde Reverter
            btnPagarEl.disabled = false;
            totalEl.style.color = 'var(--danger-color)';
        } else {
            btnPagarEl.style.display = 'flex'; // Mostra Pagar (desabilitado)
            btnPagarEl.textContent = 'Sem Fatura';
            btnPagarEl.disabled = true;
            btnReverterEl.style.display = 'none'; // Esconde Reverter
            totalEl.style.color = 'var(--success-color)';
        }
    });
}

/**
 * NOVO (v5.0): Renderiza o KPI de total de gastos dos cartões
 */
function renderTotalGastosCartoes() {
    let totalMes = 0;
    for (const id in estadoFaturas) {
        totalMes += estadoFaturas[id].total;
    }
    totalGastosCartoesEl.textContent = formatCurrency(totalMes);
}

/**
 * (Helper) Renderiza o HTML de uma única linha de gasto para a tabela da fatura.
 * (v4.0 - Lógica de Strikethrough)
 */
function renderLinhaGasto(gasto) {
    const data = gasto.data || gasto.vencimento;
    const [y, m, d] = data.split('-');
    const dataFormatada = `${d}/${m}/${y}`;
    
    let icone = "💳";
    if (gasto.tipo === 'variavel') icone = categoriaIcones[gasto.categoria] || "📦";
    else if (gasto.tipo === 'fixo') icone = categoriaFixosIcones[gasto.categoria] || "📦";
    else if (gasto.tipo === 'spec') icone = "🔄";

    const isStrikethrough = gasto.isStrikethrough || false;
    const openTag = isStrikethrough ? '<del style="color: var(--text-light);">' : ''; 
    const closeTag = isStrikethrough ? '</del>' : '';

    return `<tr>
                <td>${openTag}${dataFormatada}${closeTag}</td>
                <td>${openTag}${icone} ${gasto.descricao}${closeTag}</td>
                <td>${openTag}${formatCurrency(gasto.valor)}${closeTag}</td>
            </tr>`;
}

/**
 * (Helper) A LÓGICA DE VIRADA.
 * (v3.7 - Sem mudanças)
 */
function calcularMesFatura(dataGasto, diaFechamento) {
    const dia = dataGasto.getDate();
    const mes = dataGasto.getMonth(); // 0 = Jan, 11 = Dez
    const ano = dataGasto.getFullYear();

    if (dia >= diaFechamento) {
        return new Date(ano, mes + 1, 1);
    } else {
        return new Date(ano, mes, 1);
    }
}


// ===============================================================
// FASE 3B: LÓGICA DE PAGAMENTO (Atualizado v5.0)
// ===============================================================

// (v4.0 - Sem mudanças)
async function handlePagarFaturaClick(cartao, valor) {
    if (valor <= 0) {
        alert("Esta fatura não tem valor a ser pago.");
        return;
    }

    const temSaldo = await verificarSaldoSuficiente(valor);
    if (!temSaldo) {
        alert("❌ Saldo em Caixa insuficiente para pagar esta fatura!");
        return; 
    }
    
    const valorFormatado = formatCurrency(valor);
    
    const pagarFn = async () => {
        document.querySelectorAll('.fatura-header button').forEach(btn => btn.disabled = true);

        try {
            await updateSaldoGlobal(-valor);
            await registrarPagamentoFatura(cartao, valor);
            hideModal('modal-confirm');
        } catch (error) {
            console.error("Erro ao pagar fatura:", error);
            alert("Não foi possível processar o pagamento.");
            loadGastosAgregados(); 
        }
    };
    
    modalMessage.textContent = `Confirmar pagamento de ${valorFormatado} da fatura ${cartao.nome}? O valor sairá do seu Saldo em Caixa.`;
    showModal('modal-confirm', pagarFn);
}

/**
 * NOVO (v5.0): Reverte um pagamento de fatura
 */
async function handleReverterPagamentoClick(cartao, valor) {
    modalReverterMessage.textContent = `Tem certeza que quer reverter o pagamento da fatura ${cartao.nome} (${formatCurrency(valor)})? O valor será devolvido ao seu Saldo em Caixa.`;

    const reverterFn = async () => {
        const path = `dados/${userId}/pendencias/${currentYear}-${currentMonth}`;
        const pendenciasRef = ref(db, path);
        
        try {
            const snapshot = await get(pendenciasRef);
            let pagamentoId = null;
            if (snapshot.exists()) {
                snapshot.forEach(child => {
                    const pendencia = child.val();
                    if (pendencia.descricao === `Pagamento Fatura ${cartao.nome}` && pendencia.status === 'pago') {
                        pagamentoId = pendencia.id;
                    }
                });
            }

            if (!pagamentoId) {
                throw new Error("Registo de pagamento não encontrado em 'pendencias'.");
            }

            // 1. Remove o registo de pagamento
            await remove(ref(db, `${path}/${pagamentoId}`));
            
            // 2. Devolve o dinheiro ao saldo
            await updateSaldoGlobal(valor);

            hideModal('modal-reverter-confirm');
            // O listener de 'pendencias' em loadGastosAgregados vai
            // automaticamente recarregar a UI e marcar a fatura como 'não paga'

        } catch (error) {
            console.error("Erro ao reverter pagamento:", error);
            alert("Não foi possível reverter o pagamento.");
            hideModal('modal-reverter-confirm');
        }
    };

    // Remove listeners antigos do modal de reversão
    const newBtnConfirm = btnReverterConfirm.cloneNode(true);
    btnReverterConfirm.parentNode.replaceChild(newBtnConfirm, btnReverterConfirm);
    
    newBtnConfirm.onclick = reverterFn;
    btnReverterCancel.onclick = () => hideModal('modal-reverter-confirm');
    
    modalReverter.style.display = 'flex';
}


// (v4.0 - Sem mudanças)
async function updateSaldoGlobal(ajuste) {
    if (ajuste === 0) return; 
    const saldoRef = ref(db, `dados/${userId}/saldo/global`);
    try {
        const snapshot = await get(saldoRef);
        let saldoAcumulado = snapshot.val()?.saldoAcumulado || 0;
        saldoAcumulado += ajuste;
        await set(saldoRef, { saldoAcumulado: saldoAcumulado });
    } catch (error) {
        console.error("Erro ao atualizar saldo global:", error);
        throw error;
    }
}

// (v4.0 - Sem mudanças, exceto fuso horário)
async function registrarPagamentoFatura(cartao, valor) {
    const path = `dados/${userId}/pendencias/${currentYear}-${currentMonth}`;
    
    // (Correção de fuso v4.0)
    const dataPagamentoObj = new Date();
    dataPagamentoObj.setMinutes(dataPagamentoObj.getMinutes() - dataPagamentoObj.getTimezoneOffset());
    const dataPagamento = dataPagamentoObj.toISOString().split('T')[0];
    
    const pagamento = {
        vencimento: dataPagamento,
        descricao: `Pagamento Fatura ${cartao.nome}`, 
        tipo: 'euDevo',
        status: 'pago',
        valor: valor,
        formaPagamento: 'Saldo em Caixa', 
        pessoa: cartao.nome, 
        parcelaInfo: { 
            grupoId: null, 
            atual: 1, 
            total: 1 
        }
    };
    
    try {
        const newRef = push(ref(db, path));
        await set(newRef, { ...pagamento, id: newRef.key });
    } catch (error) {
        console.error("Erro ao registrar pagamento:", error);
        throw error;
    }
}

// ---- Funções Utilitárias de Modal (Simples) ----
// (v4.0 - Sem mudanças)
function showModal(modalId, confirmFn) {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    
    modal.style.display = 'flex';

    const btnConfirm = document.getElementById('modal-btn-confirm');
    const btnCancel = document.getElementById('modal-btn-cancel');

    // Clona para remover listeners antigos
    const newBtnConfirm = btnConfirm.cloneNode(true);
    const newBtnCancel = btnCancel.cloneNode(true);
    
    newBtnConfirm.onclick = confirmFn;
    newBtnCancel.onclick = () => hideModal(modalId);

    btnConfirm.replaceWith(newBtnConfirm);
    btnCancel.replaceWith(newBtnCancel);
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if(modal) {
        modal.style.display = 'none';
    }
}